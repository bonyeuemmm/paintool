import paintoolpremium

if __name__ == '__main__':
    paintoolpremium.verify_and_start()